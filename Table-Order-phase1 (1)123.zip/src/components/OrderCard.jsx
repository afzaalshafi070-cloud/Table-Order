import { locationLabel } from '../utils/locationLabel.js'

const STATUS_META = {
  pending: { label: 'New', color: 'var(--mustard)' },
  cooking: { label: 'Cooking', color: 'var(--sage)' },
  served: { label: 'Served', color: 'var(--text-muted)' },
}

export default function OrderCard({
  order,
  hasWaterAlert,
  hasWaiterAlert,
  hasBillAlert,
  onAccept,
  onServe,
  onResolveAlert,
  onPrint,
}) {
  const meta = STATUS_META[order.status] || STATUS_META.pending
  const flashing = hasWaterAlert || hasBillAlert
  const isNew = order.status === 'pending'

  return (
    <div
      className={`ticket-in${isNew ? ' order-new' : ''}`}
      style={{
        background: 'var(--surface)',
        border: flashing
          ? '2px solid var(--sky)'
          : isNew
            ? '2px solid var(--brand-primary)'
            : '1px solid var(--border, var(--line))',
        borderRadius: 'var(--radius)',
        padding: 14,
        display: 'flex',
        flexDirection: 'column',
        gap: 8,
        animation: flashing ? 'waterFlash 1s infinite' : undefined,
        position: 'relative',
        // Smooth colour change when status moves New -> Cooking -> Served
        transition: 'border-color .35s var(--ease-out, ease), background-color .35s var(--ease-out, ease)',
      }}
    >
      {flashing && (
        <div
          style={{
            position: 'absolute',
            top: -10,
            right: 10,
            background: 'var(--sky)',
            color: '#fff',
            fontSize: 11,
            fontWeight: 700,
            padding: '3px 8px',
            borderRadius: 6,
          }}
        >
          💧 WATER
        </div>
      )}
      {hasWaiterAlert && (
        <div
          style={{
            position: 'absolute',
            top: -10,
            left: 10,
            background: 'var(--clay)',
            color: '#fff',
            fontSize: 11,
            fontWeight: 700,
            padding: '3px 8px',
            borderRadius: 6,
          }}
        >
          🔔 WAITER
        </div>
      )}
      {hasBillAlert && (
        <div
          style={{
            position: 'absolute',
            top: -10,
            left: hasWaiterAlert ? 90 : 10,
            background: '#0f172a',
            color: '#fff',
            fontSize: 11,
            fontWeight: 700,
            padding: '3px 8px',
            borderRadius: 6,
          }}
        >
          🧾 BILL
        </div>
      )}

      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'baseline',
          gap: 8,
        }}
      >
        <strong style={{ fontFamily: 'var(--mono)', fontSize: 14 }}>
          {order.fulfillment === 'delivery'
            ? 'DELIVERY'
            : order.fulfillment === 'takeaway'
              ? 'TAKEAWAY'
              : locationLabel(order.table_id)}
        </strong>
        <span style={{ fontSize: 11, fontWeight: 700, color: meta.color, transition: 'color .35s var(--ease-out, ease)' }}>
          {meta.label.toUpperCase()}
        </span>
      </div>
      {order.fulfillment === 'delivery' && (
        <div
          style={{
            fontSize: 12,
            background: '#e0f2fe',
            borderRadius: 8,
            padding: '6px 8px',
          }}
        >
          {order.area_name && (
            <div>
              <b>Area:</b> {order.area_name}
            </div>
          )}
          {order.customer_name && (
            <div>
              {order.customer_name} · {order.customer_phone}
            </div>
          )}
          {order.customer_address && <div>{order.customer_address}</div>}
        </div>
      )}
      {order.fulfillment === 'takeaway' &&
        (order.customer_name || order.customer_phone) && (
          <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
            {order.customer_name} {order.customer_phone}
          </div>
        )}

      <div style={{ fontSize: 13, lineHeight: 1.5, flex: 1 }}>
        {order.items.map((it, idx) => (
          <div key={idx}>
            {it.qty} × {it.name}
          </div>
        ))}
      </div>
      {order.note && (
        <div style={{ fontSize: 12, fontStyle: 'italic', color: 'var(--text-muted)' }}>
          Note: {order.note}
        </div>
      )}
      <div style={{ fontFamily: 'var(--mono)', fontSize: 13 }}>
        PKR {Number(order.total).toFixed(0)}
      </div>

      <div style={{ display: 'flex', gap: 8, marginTop: 4, flexWrap: 'wrap' }}>
        {order.status === 'pending' && (
          <button
            onClick={() => onAccept(order)}
            style={{
              flex: 1,
              background: 'var(--sage)',
              color: '#fff',
              border: 'none',
              borderRadius: 8,
              padding: '8px 0',
              fontWeight: 700,
              fontSize: 13,
            }}
          >
            Accept & Cook
          </button>
        )}
        {order.status === 'cooking' && (
          <button
            onClick={() => onServe(order)}
            style={{
              flex: 1,
              background: 'var(--ink)',
              color: '#fff',
              border: 'none',
              borderRadius: 8,
              padding: '8px 0',
              fontWeight: 700,
              fontSize: 13,
            }}
          >
            Mark Served
          </button>
        )}
        <button
          onClick={() => onPrint(order, 'kot')}
          aria-label="Print KOT"
          style={{
            background: 'var(--paper-dim)',
            border: '1px solid var(--line)',
            borderRadius: 8,
            padding: '8px 12px',
            fontSize: 13,
            fontWeight: 600,
          }}
        >
          🍳 KOT
        </button>
        <button
          onClick={() => onPrint(order, 'bill')}
          aria-label="Print Bill"
          style={{
            background: 'var(--paper-dim)',
            border: '1px solid var(--line)',
            borderRadius: 8,
            padding: '8px 12px',
            fontSize: 13,
            fontWeight: 600,
          }}
        >
          🧾 Bill
        </button>
        {(hasWaterAlert || hasWaiterAlert) && (
          <button
            onClick={() => onResolveAlert(order.table_id)}
            style={{
              background: 'var(--paper-dim)',
              border: '1px solid var(--line)',
              borderRadius: 8,
              padding: '8px 12px',
              fontSize: 13,
            }}
          >
            Clear flag
          </button>
        )}
      </div>
      <style>{`
        @keyframes waterFlash {
          0%, 100% { box-shadow: 0 0 0 0 rgba(63,159,214,0.5); }
          50% { box-shadow: 0 0 0 6px rgba(63,159,214,0.15); }
        }
      `}</style>
    </div>
  )
}
